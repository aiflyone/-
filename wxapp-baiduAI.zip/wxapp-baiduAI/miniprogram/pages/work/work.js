//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    tempFilePaths: null,
    fileID:null,
    disabled:true,
    imgurl:null,
    num:0
  },

  //确定图片来源，从相册中选择或者是拍照
  chooseimage: function () {
    var that = this;
    wx.showActionSheet({
      itemList: ['从相册中选择', '拍照'],
      itemColor: "#CED63A",
      success: function (res) {
        if (!res.cancel) {
          if (res.tapIndex == 0) {
            that.chooseWxImage('album')
          } else if (res.tapIndex == 1) {
            that.chooseWxImage('camera')
          }
        }
      }
    })

  },

  //选择图片
  chooseWxImage: function (type) {
    var that = this;
    wx.chooseImage({
      sizeType: ['original', 'compressed'],
      sourceType: [type],
      success: function (res) {
        const filePath = res.tempFilePaths[0];
        const cloudPath = 'my-image' +that.data.num+ filePath.match(/\.[^.]+?$/)[0];
        that.setData({
          tempFilePaths: res.tempFilePaths,
        })
        wx.cloud.uploadFile({
          cloudPath:cloudPath,
          filePath:filePath,
          success(e){
            that.setData({
              fileID:e.fileID,
            })
            wx.cloud.getTempFileURL({
              fileList:[e.fileID],
              success:function(a){
                console.log(a)
                that.setData({
                  imgurl:a.fileList[0].tempFileURL,
                  disabled:false
                })
                console.log(that.data.imgurl)
              }
            })
          }
        })
      }
    })
  },

  jump: function(){
    wx.navigateTo({
      url: '../index/index?imgurl='+this.data.imgurl,
    })
  },

  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },

  onShow:function(){
    this.setData({
      num:this.data.num+1,
      disabled:true
    })
    wx.cloud.deleteFile({
      fileList:[this.data.fileID],
      success(res){
        console.log(res)
      }
    })
  },

  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
